import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // IMPORTANT: Change 'YOUR_REPOSITORY_NAME' to the actual name of your GitHub repository.
  // For example, if your repo URL is https://github.com/user/my-islamic-app,
  // then the base should be '/my-islamic-app/'.
  base: '/YOUR_REPOSITORY_NAME/',
})
